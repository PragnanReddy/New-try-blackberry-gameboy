package com.example.gblauncher

import android.app.admin.DeviceAdminReceiver

/** Lets the launcher lock the screen. Grants nothing beyond "force lock". */
class LockAdmin : DeviceAdminReceiver()
