package com.example.gblauncher

import android.app.Activity
import android.app.AlertDialog
import android.app.WallpaperManager
import android.app.admin.DevicePolicyManager
import android.content.ComponentName
import android.app.role.RoleManager
import android.content.pm.PackageManager
import android.os.Build
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.ResolveInfo
import android.graphics.*
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.BatteryManager
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.text.Editable
import android.text.TextWatcher
import android.view.Gravity
import android.view.HapticFeedbackConstants
import android.graphics.drawable.StateListDrawable
import android.view.KeyEvent
import android.view.View
import android.view.ViewGroup
import android.widget.*
import java.text.SimpleDateFormat
import java.util.*

class MainActivity : Activity() {

    // Classic four-shade green palette
    private val C0 = 0xFF0F380F.toInt()
    private val C1 = 0xFF306230.toInt()
    private val C2 = 0xFF8BAC0F.toInt()
    private val C3 = 0xFF9BBC0F.toInt()
    private val BODY = 0xFFCDC9C0.toInt()
    private val BEZEL = 0xFF55556A.toInt()
    private val MAGENTA = 0xFF9A2257.toInt()
    private val PAD = 0xFF2B2B33.toInt()

    private val mono: Typeface = Typeface.create(Typeface.MONOSPACE, Typeface.BOLD)
    private val handler = Handler(Looper.getMainLooper())
    private val iconCache = HashMap<String, Bitmap>()

    private var all: List<Entry> = emptyList()
    private var shown: List<Entry> = emptyList()
    private var selected = 0
    private var askedThisRun = false

    private lateinit var list: ListView
    private lateinit var adapter: AppAdapter
    private lateinit var clock: TextView
    private lateinit var info: TextView
    private lateinit var search: EditText

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildUi()
    }

    override fun onResume() {
        super.onResume()
        loadApps()
        tick.run()
        askToBeDefault()
    }

    private fun isDefaultHome(): Boolean {
        val ri = packageManager.resolveActivity(
            Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME), PackageManager.MATCH_DEFAULT_ONLY)
        return ri?.activityInfo?.packageName == packageName
    }

    private fun askToBeDefault() {
        val prefs = getSharedPreferences("gb", MODE_PRIVATE)
        if (isDefaultHome() || prefs.getBoolean("skipDefault", false) || askedThisRun) return
        askedThisRun = true
        AlertDialog.Builder(this)
            .setTitle("SET AS HOME?")
            .setMessage("Make DMG Launcher your default home screen.")
            .setPositiveButton("YES") { _, _ ->
                try {
                    val rm = getSystemService(RoleManager::class.java)
                    if (Build.VERSION.SDK_INT >= 29 && rm.isRoleAvailable(RoleManager.ROLE_HOME))
                        startActivityForResult(rm.createRequestRoleIntent(RoleManager.ROLE_HOME), 7)
                    else startActivity(Intent(Settings.ACTION_HOME_SETTINGS))
                } catch (e: Exception) { startActivity(Intent(Settings.ACTION_SETTINGS)) }
            }
            .setNegativeButton("LATER", null)
            .setNeutralButton("DON'T ASK") { _, _ -> prefs.edit().putBoolean("skipDefault", true).apply() }
            .show()
    }

    override fun onPause() {
        super.onPause()
        handler.removeCallbacks(tick)
    }

    override fun onNewIntent(intent: Intent?) {
        super.onNewIntent(intent)
        // Home pressed: reset to top
        search.setText("")
        selected = 0
        list.setSelection(0)
        adapter.notifyDataSetChanged()
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        if (search.text.isNotEmpty()) search.setText("") else moveTo(0)
    }

    // ---------- UI ----------
    private val KEYBG = 0xFF16161B.toInt()
    private val KEYTXT = 0xFFD8D8E0.toInt()
    private val rowLetters = "QWERTYUIOP"
    private val rowDigits = "1234567890"
    private val topKeys = ArrayList<TextView>()
    private var altOn = false
    private lateinit var altKey: TextView

    private fun buildUi() {
        window.statusBarColor = C0
        window.navigationBarColor = KEYBG
        val match = ViewGroup.LayoutParams.MATCH_PARENT
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(KEYBG) }

        // ===== TOP HALF: pixel screen =====
        val screen = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setBackgroundColor(C3)
            setPadding(dp(8), dp(6), dp(8), dp(4))
        }
        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL; setPadding(dp(4), 0, dp(4), dp(4))
        }
        clock = tv("--:--", 20f, C0)
        var lastTap = 0L
        clock.setOnClickListener {   // double-tap the clock to lock
            val n = System.currentTimeMillis()
            if (n - lastTap < 400) runAction("lock")
            lastTap = n
        }
        info = tv("", 12f, C0).apply { gravity = Gravity.END }
        header.addView(clock, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        header.addView(info, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        screen.addView(header)
        screen.addView(View(this).apply { setBackgroundColor(C0) }, LinearLayout.LayoutParams(match, dp(2)))

        search = EditText(this).apply {   // filled by the on-screen keys
            typeface = mono; textSize = 16f; setTextColor(C0); setHintTextColor(C1)
            hint = "SEARCH>"; setBackgroundColor(C2); setSingleLine()
            setPadding(dp(8), dp(4), dp(8), dp(4))
            isFocusable = false; isFocusableInTouchMode = false; showSoftInputOnFocus = false
            addTextChangedListener(object : TextWatcher {
                override fun afterTextChanged(s: Editable?) { applyFilter() }
                override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
                override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            })
        }
        screen.addView(search, LinearLayout.LayoutParams(match, ViewGroup.LayoutParams.WRAP_CONTENT)
            .apply { topMargin = dp(4) })

        adapter = AppAdapter()
        list = ListView(this).apply {
            divider = null; setSelector(android.R.color.transparent)
            this.adapter = this@MainActivity.adapter
            isVerticalScrollBarEnabled = false
            setOnItemClickListener { _, _, pos, _ -> selected = pos; launchSelected() }
            setOnItemLongClickListener { _, _, pos, _ -> selected = pos; shown[pos].ri?.let { appMenu(it) }; true }
        }
        screen.addView(list, LinearLayout.LayoutParams(match, 0, 1f))
        root.addView(screen, LinearLayout.LayoutParams(match, 0, 1f))
        root.addView(View(this).apply { setBackgroundColor(C0) }, LinearLayout.LayoutParams(match, dp(4)))

        // ===== BOTTOM HALF: BlackBerry-style keyboard =====
        val kb = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setBackgroundColor(KEYBG)
            setPadding(dp(4), dp(6), dp(4), dp(6))
        }
        // nav row: call / menu / trackpad / back / end
        kb.addView(row(
            key("CALL", color = 0xFF8BAC0F.toInt(), size = 11f) { startActivity(Intent(Intent.ACTION_DIAL)) },
            key("MENU", size = 11f) { shown.getOrNull(selected)?.ri?.let { appMenu(it) } },
            key("▲") { moveTo(selected - 1) },
            key("●", color = C2) { launchSelected() },
            key("▼") { moveTo(selected + 1) },
            key("BACK", size = 11f) { onBackPressed() },
            key("END", color = 0xFFE0527F.toInt(), size = 11f) { lockScreen() }))
        // QWERTYUIOP (turns into 1234567890 with ALT)
        topKeys.clear()
        kb.addView(row(*Array<View>(10) { i ->
            key(rowLetters[i].toString(), size = 18f) { type(if (altOn) rowDigits[i] else rowLetters[i]) }
                .also { topKeys.add(it) }
        }))
        // ASDFGHJKL + delete
        val r2 = ArrayList<View>()
        for (c in "ASDFGHJKL") r2.add(key(c.toString(), size = 18f) { type(c) })
        r2.add(key("⌫", color = 0xFFE0527F.toInt(), onLong = { search.setText("") }) { backspace() })
        kb.addView(row(*r2.toTypedArray()))
        // ALT ZXCVBNM . enter
        altKey = key("ALT", size = 11f) { altOn = !altOn; refreshAlt() }
        val r3 = ArrayList<View>()
        r3.add(altKey)
        for (c in "ZXCVBNM") r3.add(key(c.toString(), size = 18f) { type(c) })
        r3.add(key(".", size = 18f) { type('.') })
        r3.add(key("↵", color = 0xFF8BAC0F.toInt()) { launchSelected() })
        kb.addView(row(*r3.toTypedArray()))
        // shortcuts + space
        kb.addView(row(
            key("♪", w = 1.5f, color = C2) { startActivity(Intent(this, MusicActivity::class.java)) },
            key("SPACE", w = 5f, size = 12f) { type(' ') },
            key("▶", w = 1.5f, color = C2) { startActivity(Intent(this, VideoActivity::class.java)) }))
        root.addView(kb, LinearLayout.LayoutParams(match, 0, 1f))
        setContentView(root)
    }

    private fun row(vararg keys: View) = LinearLayout(this).apply {
        orientation = LinearLayout.HORIZONTAL
        layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f)
        keys.forEach { addView(it) }
    }

    private fun key(label: String, w: Float = 1f, color: Int = KEYTXT, size: Float = 16f,
                    onLong: (() -> Unit)? = null, tap: () -> Unit): TextView = TextView(this).apply {
        fun shape(c: Int) = GradientDrawable().apply {
            setColor(c); cornerRadius = dp(5).toFloat(); setStroke(dp(1), 0xFF44444F.toInt())
        }
        text = label; textSize = size; setTextColor(color); typeface = mono; gravity = Gravity.CENTER
        background = StateListDrawable().apply {
            addState(intArrayOf(android.R.attr.state_pressed), shape(0xFF5A5A6E.toInt()))
            addState(intArrayOf(), shape(0xFF2C2C35.toInt()))
        }
        layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, w)
            .apply { setMargins(dp(2), dp(2), dp(2), dp(2)) }
        setOnClickListener { performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP); tap() }
        if (onLong != null) setOnLongClickListener { onLong(); true }
    }

    private fun type(c: Char) { search.append(c.toString().lowercase()) }

    private fun backspace() {
        val t = search.text
        if (t.isNotEmpty()) t.delete(t.length - 1, t.length)
    }

    private fun refreshAlt() {
        for (i in topKeys.indices) topKeys[i].text = (if (altOn) rowDigits[i] else rowLetters[i]).toString()
        altKey.setTextColor(if (altOn) C2 else KEYTXT)
    }

    private fun tv(t: String, size: Float, color: Int) = TextView(this).apply {
        text = t; textSize = size; setTextColor(color); typeface = mono
    }

    // ---------- Data ----------
    private fun loadApps() {
        val i = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val pm = packageManager
        val builtIns = listOf(
            Entry("Music", null, MusicActivity::class.java, Gb.NOTE),
            Entry("Video", null, VideoActivity::class.java, Gb.FILM),
            Entry("Lock", null, null, Gb.LOCK, "lock"),
            Entry("Gray mode", null, null, Gb.GRAY, "gray"),
            Entry("Lock wallpaper", null, null, Gb.WALL, "wall"))
        all = builtIns + pm.queryIntentActivities(i, 0)
            .filter { it.activityInfo.packageName != packageName }
            .map { Entry(it.loadLabel(pm).toString(), it, null, null) }
            .sortedBy { it.label.lowercase() }
        applyFilter()
    }

    private fun applyFilter() {
        val q = search.text.toString().trim().lowercase()
        shown = if (q.isEmpty()) all else all.filter { it.label.lowercase().contains(q) }
        selected = 0
        adapter.notifyDataSetChanged()
        list.setSelection(0)
        updateInfo()
    }

    private fun moveTo(i: Int) {
        if (shown.isEmpty()) return
        selected = i.coerceIn(0, shown.size - 1)
        adapter.notifyDataSetChanged()
        list.smoothScrollToPosition(selected)
        updateInfo()
    }

    private fun launchSelected() {
        val e = shown.getOrNull(selected) ?: return
        if (e.action != null) { runAction(e.action); return }
        if (e.target != null) { startActivity(Intent(this, e.target)); return }
        val intent = packageManager.getLaunchIntentForPackage(e.ri!!.activityInfo.packageName) ?: return
        startActivity(intent)
        search.setText("")
    }

    private fun runAction(a: String) {
        when (a) {
            "lock" -> lockScreen()
            "gray" -> toggleGray()
            "wall" -> setRetroLockWallpaper()
        }
    }

    private fun lockScreen() {
        val dpm = getSystemService(DevicePolicyManager::class.java)
        val cn = ComponentName(this, LockAdmin::class.java)
        if (dpm.isAdminActive(cn)) dpm.lockNow()
        else startActivity(Intent(DevicePolicyManager.ACTION_ADD_DEVICE_ADMIN)
            .putExtra(DevicePolicyManager.EXTRA_DEVICE_ADMIN, cn)
            .putExtra(DevicePolicyManager.EXTRA_ADD_EXPLANATION,
                "Only used so the LOCK entry can lock your screen."))
    }

    private fun toggleGray() {
        try {
            val on = Settings.Secure.getInt(contentResolver, "accessibility_display_daltonizer_enabled", 0) == 1
            Settings.Secure.putInt(contentResolver, "accessibility_display_daltonizer", 0)
            Settings.Secure.putInt(contentResolver, "accessibility_display_daltonizer_enabled", if (on) 0 else 1)
            Toast.makeText(this, if (on) "COLOR" else "GRAY", Toast.LENGTH_SHORT).show()
        } catch (e: SecurityException) {
            AlertDialog.Builder(this)
                .setTitle("ONE-TIME SETUP")
                .setMessage("Android needs a one-time permission for this. Run on a PC (or wireless adb):\n\n" +
                    "adb shell pm grant $packageName android.permission.WRITE_SECURE_SETTINGS\n\n" +
                    "Or turn on Settings > Accessibility > Color correction > Grayscale by hand.")
                .setPositiveButton("OPEN SETTINGS") { _, _ -> startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
                .setNegativeButton("CLOSE", null).show()
        }
    }

    private fun setRetroLockWallpaper() {
        try {
            val dm = resources.displayMetrics
            val w = 90
            val h = (w * dm.heightPixels.toFloat() / dm.widthPixels).toInt()
            val bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
            val c = Canvas(bmp); c.drawColor(C3)
            for (y in h - 10 until h) for (x in 0 until w) if ((x + y) % 2 == 0) bmp.setPixel(x, y, C1)
            for (y in 0 until 10) for (x in 0 until w) if ((x + y) % 2 == 0) bmp.setPixel(x, y, C1)
            val p = Paint().apply { isAntiAlias = false; typeface = mono; color = C0; textAlign = Paint.Align.CENTER }
            p.textSize = 26f; c.drawText("DMG", w / 2f, h * 0.42f, p)
            p.textSize = 7f; c.drawText("DOT MATRIX", w / 2f, h * 0.42f + 12f, p)
            p.textSize = 6f; c.drawText("PRESS POWER", w / 2f, h * 0.8f, p)
            val big = Bitmap.createScaledBitmap(bmp, dm.widthPixels, dm.heightPixels, false)
            WallpaperManager.getInstance(this).setBitmap(big, null, true, WallpaperManager.FLAG_LOCK)
            Toast.makeText(this, "LOCK SCREEN SET", Toast.LENGTH_SHORT).show()
        } catch (e: Exception) {
            Toast.makeText(this, "COULD NOT SET WALLPAPER", Toast.LENGTH_LONG).show()
        }
    }

    private fun toggleSearch() {
        if (search.visibility == View.VISIBLE) {
            search.setText(""); search.visibility = View.GONE
            (getSystemService(INPUT_METHOD_SERVICE) as android.view.inputmethod.InputMethodManager)
                .hideSoftInputFromWindow(search.windowToken, 0)
        } else {
            search.visibility = View.VISIBLE; search.requestFocus()
            (getSystemService(INPUT_METHOD_SERVICE) as android.view.inputmethod.InputMethodManager)
                .showSoftInput(search, 0)
        }
    }

    private fun appMenu(ri: ResolveInfo) {
        val pkg = ri.activityInfo.packageName
        val name = ri.loadLabel(packageManager).toString()
        AlertDialog.Builder(this)
            .setTitle(name)
            .setItems(arrayOf("App info", "Uninstall")) { _, which ->
                if (which == 0) startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                    Uri.parse("package:$pkg")))
                else startActivity(Intent(Intent.ACTION_DELETE, Uri.parse("package:$pkg")))
            }.show()
    }

    // ---------- Header ----------
    private val tick = object : Runnable {
        override fun run() {
            clock.text = SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date())
            updateInfo()
            handler.postDelayed(this, 15000)
        }
    }

    private fun updateInfo() {
        val b = registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        val lvl = b?.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) ?: -1
        val scale = b?.getIntExtra(BatteryManager.EXTRA_SCALE, 100) ?: 100
        val pct = if (lvl >= 0) lvl * 100 / scale else 0
        val bars = (pct / 25).coerceIn(0, 4)
        val batt = "[" + "■".repeat(bars) + "□".repeat(4 - bars) + "]"
        info.text = "${if (shown.isEmpty()) 0 else selected + 1}/${shown.size}  $batt"
    }

    // ---------- Keys ----------
    override fun onKeyDown(keyCode: Int, event: KeyEvent?): Boolean {
        if (event != null && event.isPrintingKey && !event.isCtrlPressed && event.unicodeChar != 0) {
            type(event.unicodeChar.toChar()); return true
        }
        when (keyCode) {
            KeyEvent.KEYCODE_DEL -> { backspace(); return true }
            KeyEvent.KEYCODE_ENTER -> { launchSelected(); return true }
            KeyEvent.KEYCODE_DPAD_UP -> { moveTo(selected - 1); return true }
            KeyEvent.KEYCODE_DPAD_DOWN -> { moveTo(selected + 1); return true }
            KeyEvent.KEYCODE_DPAD_CENTER -> { launchSelected(); return true }
            KeyEvent.KEYCODE_VOLUME_UP -> { moveTo(selected - 1); return true }
            KeyEvent.KEYCODE_VOLUME_DOWN -> { moveTo(selected + 1); return true }
        }
        return super.onKeyDown(keyCode, event)
    }

    // ---------- 4-shade pixel icons ----------
    private fun gbIcon(key: String, d: Drawable): Bitmap = iconCache.getOrPut(key) {
        val n = 24
        val src = Bitmap.createBitmap(n, n, Bitmap.Config.ARGB_8888)
        d.setBounds(0, 0, n, n); d.draw(Canvas(src))
        val px = IntArray(n * n)
        src.getPixels(px, 0, n, 0, 0, n, n)
        for (i in px.indices) {
            val c = px[i]
            val a = c ushr 24
            px[i] = if (a < 80) C3 else {
                val lum = 0.30 * Color.red(c) + 0.59 * Color.green(c) + 0.11 * Color.blue(c)
                when {
                    lum < 70 -> C0
                    lum < 140 -> C1
                    lum < 210 -> C2
                    else -> C3
                }
            }
        }
        val small = Bitmap.createBitmap(px, n, n, Bitmap.Config.ARGB_8888)
        Bitmap.createScaledBitmap(small, n * 4, n * 4, false) // nearest-neighbour
    }

    inner class AppAdapter : BaseAdapter() {
        override fun getCount() = shown.size
        override fun getItem(p: Int) = shown[p]
        override fun getItemId(p: Int) = p.toLong()
        override fun getView(p: Int, v: View?, parent: ViewGroup?): View {
            val row = (v as? LinearLayout) ?: LinearLayout(this@MainActivity).apply {
                orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
                setPadding(dp(6), dp(5), dp(6), dp(5))
                addView(TextView(context), LinearLayout.LayoutParams(dp(18), ViewGroup.LayoutParams.WRAP_CONTENT))
                addView(ImageView(context), LinearLayout.LayoutParams(dp(30), dp(30)))
                addView(TextView(context).apply {
                    typeface = mono; textSize = 16f; setSingleLine(); ellipsize = android.text.TextUtils.TruncateAt.END
                }, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply { leftMargin = dp(8) })
            }
            val e = shown[p]
            val sel = p == selected
            val fg = if (sel) C3 else C0
            row.setBackgroundColor(if (sel) C0 else C3)
            (row.getChildAt(0) as TextView).apply { text = if (sel) "▶" else ""; setTextColor(fg); typeface = mono }
            (row.getChildAt(1) as ImageView).apply {
                scaleType = ImageView.ScaleType.FIT_XY
                setImageBitmap(if (e.glyph != null) Gb.glyph(e.glyph)
                    else gbIcon(e.ri!!.activityInfo.packageName, e.ri.loadIcon(packageManager)))
            }
            (row.getChildAt(2) as TextView).apply {
                text = e.label.uppercase(); setTextColor(fg)
            }
            return row
        }
    }
}
