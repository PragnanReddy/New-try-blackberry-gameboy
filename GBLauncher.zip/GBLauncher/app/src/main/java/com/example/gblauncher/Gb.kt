package com.example.gblauncher

import android.Manifest
import android.app.Activity
import android.content.ContentUris
import android.content.Context
import android.content.pm.PackageManager
import android.content.pm.ResolveInfo
import android.graphics.*
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Build
import android.provider.MediaStore
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.widget.*

/** One row on the launcher home list: an installed app or a built-in screen. */
data class Entry(val label: String, val ri: ResolveInfo?, val target: Class<*>?, val glyph: Array<String>?,
                 val action: String? = null)

data class Media(val uri: Uri, val title: String, val artist: String, val durationMs: Long)

object Gb {
    const val C0 = 0xFF0F380F.toInt()
    const val C1 = 0xFF306230.toInt()
    const val C2 = 0xFF8BAC0F.toInt()
    const val C3 = 0xFF9BBC0F.toInt()
    const val BODY = 0xFFCDC9C0.toInt()
    const val BEZEL = 0xFF55556A.toInt()
    const val MAGENTA = 0xFF9A2257.toInt()
    const val PAD = 0xFF2B2B33.toInt()
    val mono: Typeface = Typeface.create(Typeface.MONOSPACE, Typeface.BOLD)

    val NOTE = arrayOf(
        "..######", "..#....#", "..#....#", "..#....#",
        "..#....#", "###..###", "###..###", ".#....#.")
    val FILM = arrayOf(
        "########", "#......#", "#.#....#", "#.###..#",
        "#.###..#", "#.#....#", "#......#", "########")

    val LOCK = arrayOf(
        "..####..", ".#....#.", ".#....#.", "########",
        "########", "###..###", "###..###", "########")
    val GRAY = arrayOf(
        "########", "#...####", "#...####", "#...####",
        "#...####", "#...####", "#...####", "########")
    val WALL = arrayOf(
        "########", "#......#", "#...#..#", "#..###.#",
        "#.#####.", "#######.", "#......#", "########")

    private val glyphCache = HashMap<Array<String>, Bitmap>()
    fun glyph(rows: Array<String>): Bitmap = glyphCache.getOrPut(rows) {
        val px = IntArray(64) { i -> if (rows[i / 8][i % 8] == '#') C0 else C3 }
        val small = Bitmap.createBitmap(px, 8, 8, Bitmap.Config.ARGB_8888)
        Bitmap.createScaledBitmap(small, 32, 32, false)
    }

    fun dp(c: Context, v: Int) = (v * c.resources.displayMetrics.density).toInt()
    fun fmt(ms: Int): String { val s = ms / 1000; return "%02d:%02d".format(s / 60, s % 60) }

    fun tv(c: Context, t: String, size: Float, color: Int) = TextView(c).apply {
        text = t; textSize = size; setTextColor(color); typeface = mono
    }

    // ---------- permissions + media queries ----------
    fun permFor(kind: String): String =
        if (Build.VERSION.SDK_INT >= 33)
            (if (kind == "audio") Manifest.permission.READ_MEDIA_AUDIO else Manifest.permission.READ_MEDIA_VIDEO)
        else Manifest.permission.READ_EXTERNAL_STORAGE

    fun hasPerm(a: Activity, kind: String) =
        a.checkSelfPermission(permFor(kind)) == PackageManager.PERMISSION_GRANTED

    fun queryAudio(c: Context): List<Media> {
        val out = ArrayList<Media>()
        val uri = MediaStore.Audio.Media.EXTERNAL_CONTENT_URI
        val proj = arrayOf(MediaStore.Audio.Media._ID, MediaStore.Audio.Media.TITLE,
            MediaStore.Audio.Media.ARTIST, MediaStore.Audio.Media.DURATION)
        c.contentResolver.query(uri, proj, "${MediaStore.Audio.Media.IS_MUSIC} != 0", null,
            "${MediaStore.Audio.Media.TITLE} COLLATE NOCASE ASC")?.use { q ->
            while (q.moveToNext()) {
                val artist = q.getString(2) ?: ""
                out += Media(ContentUris.withAppendedId(uri, q.getLong(0)), q.getString(1) ?: "?",
                    if (artist == "<unknown>") "" else artist, q.getLong(3))
            }
        }
        return out
    }

    fun queryVideo(c: Context): List<Media> {
        val out = ArrayList<Media>()
        val uri = MediaStore.Video.Media.EXTERNAL_CONTENT_URI
        val proj = arrayOf(MediaStore.Video.Media._ID, MediaStore.Video.Media.TITLE,
            MediaStore.Video.Media.DURATION)
        c.contentResolver.query(uri, proj, null, null,
            "${MediaStore.Video.Media.TITLE} COLLATE NOCASE ASC")?.use { q ->
            while (q.moveToNext())
                out += Media(ContentUris.withAppendedId(uri, q.getLong(0)), q.getString(1) ?: "?", "", q.getLong(2))
        }
        return out
    }

    // ---------- console shell (bezel + green screen + buttons) ----------
    class Keys(
        val up: () -> Unit = {}, val down: () -> Unit = {},
        val left: () -> Unit = {}, val right: () -> Unit = {},
        val a: () -> Unit = {}, val b: () -> Unit = {},
        val select: () -> Unit = {}, val start: () -> Unit = {})

    class Shell(val root: View, val screen: LinearLayout, val title: TextView, val status: TextView)

    fun shell(a: Activity, titleText: String, k: Keys): Shell {
        fun d(v: Int) = dp(a, v)
        a.window.statusBarColor = BODY
        a.window.navigationBarColor = BODY
        val root = LinearLayout(a).apply {
            orientation = LinearLayout.VERTICAL; setBackgroundColor(BODY)
            setPadding(d(14), d(14), d(14), d(10))
        }
        val bezel = LinearLayout(a).apply {
            orientation = LinearLayout.VERTICAL
            background = GradientDrawable().apply {
                setColor(BEZEL)
                cornerRadii = floatArrayOf(d(10).toFloat(), d(10).toFloat(), d(10).toFloat(), d(10).toFloat(),
                    d(40).toFloat(), d(40).toFloat(), d(10).toFloat(), d(10).toFloat())
            }
            setPadding(d(18), d(14), d(18), d(10))
        }
        val label = tv(a, "DOT MATRIX WITH STEREO SOUND", 9f, 0xFFB0B0C0.toInt()).apply {
            gravity = Gravity.CENTER; letterSpacing = 0.1f
        }
        val screen = LinearLayout(a).apply {
            orientation = LinearLayout.VERTICAL; setBackgroundColor(C3)
            setPadding(d(6), d(6), d(6), d(6))
        }
        val header = LinearLayout(a).apply {
            orientation = LinearLayout.HORIZONTAL; setPadding(d(4), 0, d(4), d(4))
        }
        val title = tv(a, titleText, 20f, C0)
        val status = tv(a, "", 12f, C0).apply { gravity = Gravity.END }
        header.addView(title, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        header.addView(status, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        screen.addView(header)
        screen.addView(View(a).apply { setBackgroundColor(C0) },
            LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, d(2)))
        bezel.addView(label)
        bezel.addView(screen, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f)
            .apply { topMargin = d(8) })
        root.addView(bezel, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))

        // controls
        val controls = RelativeLayout(a)
        val g = GridLayout(a).apply { rowCount = 3; columnCount = 3 }
        fun cell(t: String?, act: (() -> Unit)?): View = TextView(a).apply {
            text = t ?: ""; textSize = 12f; setTextColor(0xFF77778A.toInt()); gravity = Gravity.CENTER
            setBackgroundColor(PAD); if (act != null) setOnClickListener { act() }
        }
        fun lp() = GridLayout.LayoutParams().apply { width = d(36); height = d(36) }
        g.addView(View(a), lp()); g.addView(cell("▲", k.up), lp()); g.addView(View(a), lp())
        g.addView(cell("◀", k.left), lp()); g.addView(cell(null, null), lp()); g.addView(cell("▶", k.right), lp())
        g.addView(View(a), lp()); g.addView(cell("▼", k.down), lp()); g.addView(View(a), lp())
        controls.addView(g, RelativeLayout.LayoutParams(d(110), d(110)).apply {
            addRule(RelativeLayout.ALIGN_PARENT_LEFT); addRule(RelativeLayout.CENTER_VERTICAL); leftMargin = d(8)
        })
        fun round(t: String, act: () -> Unit) = TextView(a).apply {
            text = t; textSize = 14f; setTextColor(0xFFE8B6CC.toInt()); typeface = mono; gravity = Gravity.CENTER
            background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(MAGENTA) }
            setOnClickListener { act() }
        }
        val ab = LinearLayout(a).apply { orientation = LinearLayout.HORIZONTAL }
        ab.addView(round("B", k.b), LinearLayout.LayoutParams(d(54), d(54)).apply { topMargin = d(26) })
        ab.addView(round("A", k.a), LinearLayout.LayoutParams(d(54), d(54)).apply { leftMargin = d(12) })
        controls.addView(ab, RelativeLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, d(90)).apply {
            addRule(RelativeLayout.ALIGN_PARENT_RIGHT); addRule(RelativeLayout.CENTER_VERTICAL); rightMargin = d(8)
        })
        fun pill(t: String, act: () -> Unit): View {
            val box = LinearLayout(a).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER_HORIZONTAL }
            box.addView(TextView(a).apply {
                background = GradientDrawable().apply { setColor(0xFF8A8A92.toInt()); cornerRadius = d(10).toFloat() }
                setOnClickListener { act() }
            }, LinearLayout.LayoutParams(d(54), d(16)))
            box.addView(tv(a, t, 9f, BEZEL).apply { gravity = Gravity.CENTER })
            return box
        }
        val pills = LinearLayout(a).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER }
        pills.addView(pill("SELECT", k.select))
        pills.addView(pill("START", k.start), LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { leftMargin = d(18) })
        controls.addView(pills, RelativeLayout.LayoutParams(
            ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
            addRule(RelativeLayout.CENTER_HORIZONTAL); addRule(RelativeLayout.ALIGN_PARENT_BOTTOM)
        })
        root.addView(controls, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, d(150))
            .apply { topMargin = d(10) })
        return Shell(root, screen, title, status)
    }

    /** Simple inverted-selection row list used by the music and video screens. */
    class RowAdapter(
        private val a: Activity, private val count: () -> Int, private val label: (Int) -> String,
        private val selected: () -> Int, private val marked: () -> Int, private val mark: String
    ) : BaseAdapter() {
        override fun getCount() = count()
        override fun getItem(p: Int) = p
        override fun getItemId(p: Int) = p.toLong()
        override fun getView(p: Int, v: View?, parent: ViewGroup?): View {
            val t = (v as? TextView) ?: TextView(a).apply {
                typeface = mono; textSize = 15f; setSingleLine()
                ellipsize = android.text.TextUtils.TruncateAt.END
                setPadding(dp(a, 6), dp(a, 8), dp(a, 6), dp(a, 8))
            }
            val sel = p == selected()
            val lead = if (sel) "▶ " else if (p == marked()) "$mark " else "  "
            t.text = lead + label(p)
            t.setTextColor(if (sel) C3 else C0)
            t.setBackgroundColor(if (sel) C0 else C3)
            return t
        }
    }
}

/** Chunky block progress bar. Tap or drag to seek. */
class GbProgress(c: Context) : View(c) {
    var fraction = 0f
        set(v) { field = v.coerceIn(0f, 1f); invalidate() }
    var onSeek: ((Float) -> Unit)? = null
    private val p = Paint()
    override fun onDraw(canvas: Canvas) {
        val w = width.toFloat(); val h = height.toFloat()
        val den = resources.displayMetrics.density
        p.style = Paint.Style.FILL; p.color = Gb.C3; canvas.drawRect(0f, 0f, w, h, p)
        p.style = Paint.Style.STROKE; p.strokeWidth = 2f * den; p.color = Gb.C0
        canvas.drawRect(den, den, w - den, h - den, p)
        p.style = Paint.Style.FILL
        val bw = 6f * den; val gap = 2f * den
        var x = 6f * den
        val limit = 6f * den + (w - 12f * den) * fraction
        while (x + bw <= limit) { canvas.drawRect(x, 6f * den, x + bw, h - 6f * den, p); x += bw + gap }
    }
    override fun onTouchEvent(ev: MotionEvent): Boolean {
        when (ev.action) {
            MotionEvent.ACTION_DOWN, MotionEvent.ACTION_MOVE -> { fraction = ev.x / width; return true }
            MotionEvent.ACTION_UP -> { fraction = ev.x / width; onSeek?.invoke(fraction); return true }
        }
        return true
    }
}
